<!DOCTYPE html>
<html>
<head>
  <title>NITC LIFE SAVER</title>

  <link rel="stylesheet" type="text/css" href="home.css">
  
  <script src="aaa.js"></script>
<script>

$("#slideshow > div:gt(0)").hide();

setInterval(function() {
	$('#slideshow > div:first')
	.fadeOut(1000)
	.next()
	.fadeIn(1000)
	.end()
	.appendTo('#slideshow');
}, 3000);

</script>

<style>

#slideshow{
margin:50px auto;
position:absolute;
width:100%;
height:295PX;
padding:10px;
box-shadow: 0 0 20px rgba(0,0,0,0.4);
top:156px;
left:-4px;
}

#slideshow > div {
position:absolute;
top:10px;
left:10px;
right:10PX;
bottom:10px;
}

</style>


</head>

<div id="nav2">
<div id="lx8">
<img src="nit_logo.jpg"></img>
<font id="lx9">NIT Calicut</font>
<font id="lx10">Life Saver</font>
<font id="lx11">because you need a healthy future...</font>
</div>
 <img src="mainlogo.png" style="height:150px; width:200px;position:absolute;top:0px;">
<font>EMERGENCY AMBULANCE SERVICE</font>
<font id="f1">CALL : (0651)3011222</font>
<img id="i1" src="mail1.jpg">
<font id="f2">info@nitchealthcare.com</font>
<font id="f3">+91 8434530153</font>
<img id="i2" src="call.jpg">

</div>
<div id="nav1">
<ul>
  <li><a href="home.php">Home</a></li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Profile</a>
    <div class="dropdown-content">
      <a href="user_view_profile.php">View Profile</a>
      <a href="#">Edit Profile</a>
      <a href="#">Change Password</a>

    </div>
  </li>
  
 <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Medical</a>
    <div class="dropdown-content1">
      <a href="doctor.php">Search Doctor</a>
      <a href="checkmedicine.html">Search Medicine</a>
    </div>
  </li>
  
	<li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Blood</a>
    <div class="dropdown-content2">
      <a href="search_blood.php">Search Blood</a>
      <a href="index.html">Camps</a>
    </div>
  </li>
  
	<li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Request</a>
    <div class="dropdown-content3">
      <a href="view_blood_request.php">View Request</a>
      <a href="#">Send Request</a>
    </div>
  </li>
  
	<li><a href="#">Safety</a></li>
	<li><a href="contact_us.php">Contact Us</a></li>
	<li style="position:absolute;left:1200px"><a href="donor_login.php">Log Out</a></li>
  
</ul>
</div>

<div id="slideshow">

	<div>
		<img src="maingate.jpg" style="width:100%;height:295px;">
	</div>
	
	<div>
		<img src="nitgate.jpg" style="width:100%;height:295px;">
		</div>
		
		<div>
		
		<img src="healtcare pic/health1.jpg" style="width:100%;height:295px;">
		
		</div>
		
		<div>
		
		<img src="healtcare pic/health2.jpg" style="width:100%;height:295px;">
		
		</div>
		
		<div>
		
		<img src="healtcare pic/health3.jpg" style="width:100%;height:295px;">
		
		</div>
		
		<div>
		
		<img src="healtcare pic/health4.jpg" style="width:100%;height:295px;">
		
		</div>
		
		
		
		<div>
		
		<img src="healtcare pic/health6.jpg" style="width:100%;height:295px;">
		
		</div>
		
			
		<div>
		
		<img src="healtcare pic/health7.jpg" style="width:100%;height:295px;">
		
		</div>
		
			
		<div>
		
		<img src="healtcare pic/health8.jpg" style="width:100%;height:295px;">
		
		</div>
		
		</div>

	
	
	
	
  

<video width="700" height="430" style="position:absolute;left:300px;top:690px;"controls>
  <source src="blood.mp4" type="video/mp4">
  Your browser does not support HTML5 video.
</video>



</body> 
</html>
<div id="lx3">

	<div id="lx4">
	
	<font><center>Recent Activities</center></font>

	</div>

	
<div class="sidebar" style="height:200px; position:absolute;top:50px;">
		
			<div class="blog_posts">

    <marquee direction="up" scrolldelay="300" style="height:500px;"><table >
<tr><td>
                         <div class="blog_desc">
							<span style="font-weight:bold"><b>HDFC Bank sets Guinness record in blood collection</b>
<p>The blood donation camp organised by HDFC Bank on December 6, 2013 involving 61,902 participants has found a place </p></span>
							
						 </div>	
                         <br />
	<span style="font-weight:bold"><b>World Blood Donor Day: Poor health reduces women blood donors in India</b>
<p>While the overall number of blood donors in India has grown over the years</p></span>
					  </div>
                        </td></tr>
                   
                </table></marquee>  
				 
					 <div class="clear"></div>	
				</div>	
			
			
	</div>
	<div class="clear"></div>
	</div>




	
</div>

<div id="lx5">

<div id="lx7">

<font><center>HEAD OF HEALTH CARE</center></font>

</div>

<img src="unknown.jpg" height="150px" width="240px"></img>
<font style="position:absolute; top:180px; left:30px;"><h2>Mr.XYZ</h2></font>
<font style="position:absolute; top:215px; left:30px;"><h3>Head of Health Center</h3></font>
</div>




<div id="lx19">


<img src="dochealth.png" style="position:absolute; width:240px;height:250px;"></img>



</div>

<div id="lx6">
<img src="arrow.png" height="40px" width="120px"></img>
<font style="position:absolute;bottom:8px; font-size:20px;left:4px;color:#fefbc8;">Latest News</font>
<marquee width="90%" height="60px" direction="left"  style="font-family:Book Antiqua;position:absolute;top:8px; color:#b16f35"  scrolldelay="100" ></img><font style="font-size:20px;">Blood camp is going to start soon in college campound.</font><font style="color:#fefbc8;">aaaaaaaaaaaaaa</font><font style="font-size:20px;">Swine flu has spread all over the calicut.</font></marquee>
</div>


<div id="lx12">

	<img src="dir.jpg" style="width:90px;height:90px;border-radius:50%;position:absolute;left:4px;top:6px;"></img>
	<font>DIRECTOR</font>
	<font style="position:absolute;top:50px;font-size:16px;color:#b16f35;">SIVAJI CHAKRAVORTI</font>
</div>





<div id="lx13">
<img src="chair.jpg" style="width:90px;height:90px;border-radius:50%;position:absolute;left:4px;top:6px;"></img>
<font>CHAIRPERSON</font>
<font style="position:absolute;top:50px;font-size:16px; color:#b16f35;">ARUNA JAYANTHI</font>

</div>

<div id="footer">

<a href="#"><img src="facebook1.png" style="width:100px;height:80px;position:absolute;top:70px;left:1100px;"></img></a>
<a href="#"><img src="youtube.png" style="width:50px;height:50px;position:absolute;top:80px;left:1200px;"></img></a>
<a href="#"><img src="twitter1.png" style="width:50px;height:50px;position:absolute;top:80px;left:1275px;"></img></a>

</div>

<div style="height:50px; width:100%;background:#b16f35; position:absolute;bottom:-790px;left:0px;">
<p style="color:#fefbc8">&copy; 2017 Designed by NITC Calicut<p>
</div>



<form>

</form>

</body>

</html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php
 include "make_connection.php";
 session_start();
	$user = $_SESSION['user'];
  $select="SELECT * FROM register where email='$user'" ;
  $result = mysqli_query($conn,$select);
  while($userrow=mysqli_fetch_array($result))
  {
  $firstname=$userrow['firstname'];
  $lastname = $userrow['lastname'];
  $age=$userrow['age'];
  $usermobile=$userrow['mobile'];
  $bloodtype=$userrow['bloodtype'];
  $email=$userrow['email'];
  $address=$userrow['address'];
      $image=$userrow['avatar'];
  }
?>
<html>

	<head>
	
	

		<title>nitc</title>
		<link rel="stylesheet" type="text/css" href="user_view_profile.css">
		
 <style>
 
	#display{
	
	margin-top:0%;
	font-size:20px;
	background-color:white;
	position:absolute;
	width:100%;
	height:150px;
	}
	</style>
</head>

<div id="display" style="height:600px;width:500px; background-color:white; position:absolute;left:400px;top:170px;">
<img src="frame.png" style="width:100%;height:100%;"></img>
<img src="circle.png" style="position:absolute;left:117px; top:-28px;height:220px;"></img>
  <font style="position:absolute;left:160px; top:150px;font-size:40px;"> <?php echo $firstname; ?>
  </font>
  <font style="position:absolute;left:220px; top:150px;font-size:40px;"><span><?php echo $lastname; ?></span>
  </font>
   <font style="position:absolute;left:10px; top:20px;font-size:25px;"><span>Age  <?php echo $age; ?></span> 
  </font>
  <font style="position:absolute;left:190px; top:210px;font-size:25px;"><span><?php echo $usermobile; ?></span>
  </font>
  <p><span><?php echo $bloodtype; ?></span>
  </p>
  <font style="position:absolute;left:155px; top:275px;font-size:25px;"><span><?php echo $email; ?></span>
  </font>
  <font style="position:absolute;left:205px; top:245px;font-size:25px;"><span><?php echo $address; ?></span>
  </font>
   
    <img src="<?php echo $image ?>" height="120px" width="120px" style="position:absolute;border-radius:50%; top:10px; left:170px;" /></a></td>
  <br />
</div>
</html>
<?php
$conn = mysqli_connect('localhost','root','','nitc_life');

if(!$conn)
{
	die('unable to connect'.mysqli_connect_error());
}
?>
<html>
<body>
</body>
</html>